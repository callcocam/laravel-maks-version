<div class="cx-sidebar">
	<div class="sidebar" style="background-image: url({{ menu_asset('img/sidebar.jpg') }})">
	  <h2><a href="http://codexshaper.com">CodexShaper</a></h2>
	  <div class="sidebar-wrapper">
	      {{ menu('Admin') }}
	  </div>
	</div>
</div>
